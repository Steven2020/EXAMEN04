package com.example.david.pachecodavid;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    EditText canthabur, cantcerve, cantensa, cantsalchi;
    TextView datos, prohambur, procerve, proensa, prosalchi;
    Button botonCalcular;

    String aux;
    String[] valores;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prohambur = (TextView) findViewById(R.id.txt1);
        procerve = (TextView) findViewById(R.id.txt2);
        proensa = (TextView) findViewById(R.id.txt3);
        prosalchi = (TextView) findViewById(R.id.txt4);


        cantcerve  =(EditText) findViewById(R.id.txtcervesa);
        cantensa  =(EditText) findViewById(R.id.txtensalada);
        canthabur  =(EditText) findViewById(R.id.txtHamburguesa);
        cantsalchi  =(EditText) findViewById(R.id.txtsalchipapa);

        //hambur = (EditText) findViewById(R.id.txtHamburguesa);

        datos = (TextView) findViewById(R.id.lbldatos);
        botonCalcular = (Button) findViewById(R.id.btnCalcular);

        cantsalchi.setText("0");
        canthabur.setText("0");
        cantensa.setText("0");
        cantcerve.setText("0");

        botonCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputStream input = getResources().openRawResource(R.raw.raw_archivo);
                BufferedReader lector = new BufferedReader(new InputStreamReader(input));
                try {
                    //datos.setText(lector.readLine());
                    aux = lector.readLine();
                    valores = aux.split(";");

                    String txthambu = valores[0];
                    double n1 = Double.parseDouble(valores[1]);
                    int cant1;// =
                    cant1 = Integer.parseInt(canthabur.getText().toString());
                    double x1 = n1 * cant1;
                    prohambur.setText(txthambu);


                    String txtcerve = valores[2];
                    double n2 = Double.parseDouble(valores[3]);
                    int cant2;
                    cant2 = Integer.parseInt(cantcerve.getText().toString());
                    double x2 = n2 * cant2;
                    procerve.setText(txtcerve);

                    String txtensa = valores[4];
                    double n3 = Double.parseDouble(valores[5]);
                    int cant3;
                    cant3 = Integer.parseInt(cantensa.getText().toString());
                    double x3 = n3 * cant3;
                    prosalchi.setText(txtensa);

                    String txtsalchi = valores[6];
                    double n4 = Double.parseDouble(valores[7]);
                    int cant4;
                    cant4 = Integer.parseInt(cantsalchi.getText().toString());
                    double x4 = n4 * cant4;
                    proensa.setText(txtsalchi);

                    double x = x1 + x2 + x3 + x4;
                    double iva;
                    double total;
                    if (x < 10){
                        datos.setText("Detalle de la compra sin IVA:\n" + "\n"
                        +"\n" + String.valueOf(cant1) + " Hamburguesa a " + valores[1]+" = "+ String.valueOf(x1)
                        + "\n" + String.valueOf(cant2) + "Cevesa Club a " + valores[3]+" = "+ String.valueOf(x2)
                                + "\n" + String.valueOf(cant3) + "Emsalada a " + valores[5]+" = "+ String.valueOf(x3)
                                + "\n" + String.valueOf(cant4) + "Salchipapa a " + valores[3]+" = "+ String.valueOf(x4)
                        + "\n" + "\n total a pagar" + String.valueOf(String.valueOf(x)));

                    }

                    if (x >= 10){
                        double i = (x * 12) / 100;
                        total = x + i;
                        datos.setText("Detalle de la compra incluido el IVA:\n" + "\n"
                                +"\n" + String.valueOf(cant1) + " Hamburguesa a " + valores[1]+" = "+ String.valueOf(x1)
                                + "\n" + String.valueOf(cant2) + "Cevesa Club a " + valores[3]+" = "+ String.valueOf(x2)
                                + "\n" + String.valueOf(cant3) + "Emsalada a " + valores[5]+" = "+ String.valueOf(x3)
                                + "\n" + String.valueOf(cant4) + "Salchipapa a " + valores[3]+" = "+ String.valueOf(x4)
                                + "\n" + "\n total a pagar" + String.valueOf(String.valueOf(total)));

                    }

                    lector.close();
                } catch (IOException e){
                    e.printStackTrace();
                }
            }
        });
    }
}
